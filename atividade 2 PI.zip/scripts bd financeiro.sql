CREATE DATABASE db_financeiro;
USE db_financeiro;

-- criação da tabela funcionario --------------------------------------------------------

CREATE TABLE if not exists tbl_funcionario (


id_funcionario INT AUTO_INCREMENT,
nome_funcionario VARCHAR(50) NOT NULL ,
Nascimento_funcionario DATE NOT NULL,
setor_funcionario VARCHAR(20) NOT NULL,
cargo_funcionario VARCHAR (20) NOT NULL,
endereco VARCHAR (100),
num_dependentes INT ,
num_ident_fiscal VARCHAR(20),
admissao_funcionario DATE NOT NULL,
PRIMARY KEY (id_funcionario)
);

-- Inserção de dados de Povoaento na tabela ------------------------------------------------

iNSERT INTO tbl_funcionario (nome_funcionario, Nascimento_funcionario, setor_funcionario, cargo_funcionario, endereco, num_dependentes, num_ident_fiscal, admissao_funcionario)
VALUES
('João Silva', '1990-06-12', 'Vendas', 'Vendedor', 'Rua das Flores, 123', 2, '12345678901', '2018-01-15'),
('Maria Souza', '1985-12-03', 'RH', 'Analista de Recursos Humanos', 'Avenida dos Sonhos, 456', 0, '23456789012', '2016-05-20'),
('Lucas Oliveira', '1992-08-25', 'TI', 'Desenvolvedor Web', 'Rua das Árvores, 789', 1, '34567890123', '2019-11-01'),
('Amanda Santos', '1995-03-17', 'Contabilidade', 'Contadora', 'Praça da Liberdade, 321', 3, '45678901234', '2017-09-10'),
('Pedro Rocha', '1998-11-22', 'Compras', 'Comprador', 'Rua dos Girassóis, 987', 0, '56789012345', '2020-06-01');

-- criação da tabela "salario" : -----------------------------------------------------------

CREATE TABLE if not exists tbl_Salario (
    id_salario INT NOT NULL AUTO_INCREMENT,
    id_funcionario INT NOT NULL,
    data_referencia DATE NOT NULL, -- armazenará o mês e o ano ao qual o salário se refere.
    salario_base DECIMAL(10, 2) NOT NULL, -- armazenará o valor base do salário do funcionário para o mês de referência.
    horas_extras DECIMAL(10, 2) DEFAULT 0, -- armazenará o valor das horas extras trabalhadas pelo funcionário no mês de referência.
    comissao DECIMAL(10, 2) DEFAULT 0, -- armazenará o valor da comissão recebida pelo funcionário no mês de referência, se houver.
    descontos DECIMAL(10, 2) DEFAULT 0, -- armazenará o valor total dos descontos aplicados no salário do funcionário para o mês de referência, como impostos e co-participações de planos de saúde, por exemplo.
    valor_liquido DECIMAL(10, 2) NOT NULL, -- armazenará o valor líquido a ser recebido pelo funcionário no mês de referência, após os descontos e adicionais serem aplicados.
    PRIMARY KEY (id_salario),
    FOREIGN KEY (id_funcionario) REFERENCES tbl_Funcionario(id_funcionario)
);

-- inserção dados povoamento na tabela salario --------------------------------------------

INSERT INTO tbl_Salario (id_funcionario, data_referencia, salario_base, horas_extras, comissao, descontos, valor_liquido) VALUES
(1, '2022-01-01', 3000.00, 100.00, 0, 1000.00, 2200.00),
(1, '2022-02-01', 3000.00, 200.00, 0, 1000.00, 2200.00),
(1, '2022-03-01', 3000.00, 150.00, 0, 1000.00, 2150.00),
(2, '2022-01-01', 3500.00, 50.00, 0, 500.00, 3050.00),
(2, '2022-02-01', 3500.00, 100.00, 0, 500.00, 3100.00),
(2, '2022-03-01', 3500.00, 75.00, 0, 500.00, 3075.00);

-- Nesse exemplo, foram inseridos dados de salários para dois funcionários (id_funcionario 1 e 2) em três meses distintos (janeiro, fevereiro e março de 2022).

-- criação tabela beneficios -----------------------------------------------------------

CREATE TABLE beneficios (
    id INT PRIMARY KEY,
    nome VARCHAR(50) NOT NULL, -- armazenará o nome do beneficio.
    descricao VARCHAR(200) NOT NULL, -- armazenará a descrição do que este beneficio oferece.
    valor FLOAT NOT NULL -- armazenará o valor deste beneficio.
);

-- inserção de dados de povoamento na tabela beneficios : ----------------------------------

INSERT INTO beneficios (id, nome, descricao, valor) VALUES
(1, 'Plano de saúde', 'Oferece cobertura médica para consultas, exames e procedimentos', 200.00),
(2, 'Vale-alimentação', 'Ajuda a custear as despesas com alimentação dos funcionários', 250.00),
(3, 'Vale-transporte', 'Ajuda a custear as despesas com transporte dos funcionários', 150.00),
(4, 'Seguro de vida', 'Oferece uma indenização aos beneficiários em caso de morte do funcionário', 100.00),
(5, 'Auxílio-creche', 'Ajuda a custear as despesas com creche dos filhos dos funcionários', 300.00);

-- criação da tabela pagamentos : -------------------------------------------------------

CREATE TABLE pagamentos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  data_pagamento DATE NOT NULL, -- data em que o pagamento foi efetuado.
  id_funcionario INT NOT NULL, 
  salario_base DECIMAL(10,2) NOT NULL, -- salário base do funcionário.
  horas_trabalhadas DECIMAL(5,2) NOT NULL, -- quantidade de horas trabalhadas no período do pagamento.
  valor_horas_extras DECIMAL(10,2) DEFAULT 0, -- valor das horas extras trabalhadas
  valor_falta DECIMAL(10,2) DEFAULT 0, -- valor das faltas do funcionário.
  valor_transporte DECIMAL(10,2) DEFAULT 0, -- valor do auxílio transporte pago ao funcionário.
  valor_alimentacao DECIMAL(10,2) DEFAULT 0, -- valor do auxílio alimentação pago ao funcionário.
  outros_descontos DECIMAL(10,2) DEFAULT 0, -- outros descontos feitos no salário do funcionário.
  valor_total DECIMAL(10,2) NOT NULL, -- valor total de pagamento ao funcionario.
  FOREIGN KEY (id_funcionario) REFERENCES tbl_Funcionario(id_funcionario)
);

-- inserção de dados de povoamento na tabela pagamentos : --------------------------

INSERT INTO pagamentos (data_pagamento, id_funcionario, salario_base, horas_trabalhadas, valor_horas_extras, valor_falta, valor_transporte, valor_alimentacao, outros_descontos, valor_total) VALUES
('2022-01-31', 1, 5000.00, 180.00, 150.00, 0.00, 200.00, 300.00, 100.00, 6150.00),
('2022-01-31', 2, 4500.00, 170.00, 0.00, 200.00, 100.00, 250.00, 50.00, 3500.00),
('2022-01-31', 3, 6000.00, 200.00, 180.00, 0.00, 250.00, 350.00, 0.00, 7180.00),
('2022-01-31', 4, 5500.00, 160.00, 0.00, 0.00, 150.00, 200.00, 0.00, 5150.00),
('2022-01-31', 5, 4000.00, 150.00, 0.00, 0.00, 100.00, 200.00, 50.00, 3750.00);