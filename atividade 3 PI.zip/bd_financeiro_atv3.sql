use db_financeiro;

-- 1. Ajuste questões de segurança, incluindo usuários, papéis e permissões.----------------------------------------
-- Criei um usuário com permissões limitadas para acessar o banco de dados:

CREATE USER 'usuario_seguro'@'localhost' IDENTIFIED BY 'senha_segura';

-- Criei um papel com permissões específicas para acessar determinadas tabelas do banco de dados:
CREATE ROLE 'papel_seguro';
GRANT SELECT, INSERT, UPDATE ON db_financeiro.tbl_funcionario TO 'papel_seguro';
GRANT SELECT, UPDATE ON db_financeiro.tbl_Salario TO 'papel_seguro';

-- Atribui o papel ao usuário criado anteriormente:
GRANT 'papel_seguro' TO 'usuario_seguro'@'localhost';


-- 2. Crie visões no banco de dados para consultas mais frequentes.---------------------------------------------------

-- Visão para selecionar todos os funcionários ativos
CREATE VIEW vw_funcionarios_ativos AS 
SELECT * FROM tbl_funcionario WHERE ativo = true;

-- Visão para selecionar funcionários com salário maior que 5000
CREATE VIEW vw_funcionarios_salario AS 
SELECT * FROM tbl_funcionario WHERE salario > 5000;

-- visão para retornar uma tabela com as colunas "id_pagamento", "valor", "data_pagamento" e "status" da tabela "pagamentos". 
CREATE VIEW vw_pagamentos AS
SELECT id_pagamento, valor, data_pagamento, status
FROM pagamentos;


-- 3. Crie ao menos uma stored function, um stored procedure ou um trigger para o banco de dados, selecionando uma funcionalidade que seja adequada para tanto.--------
 
 -- criei um trigger que calcula o valor líquido de um salário automaticamente toda vez que um novo registro de salário for inserido na tabela "tbl_salario".
-- O valor líquido será calculado subtraindo os descontos, horas extras e comissão (se houver) do salário base.

CREATE TRIGGER calcular_valor_liquido AFTER INSERT ON tbl_salario
FOR EACH ROW
BEGIN
    DECLARE valor_liquido DECIMAL(10,2);
    SET valor_liquido = NEW.salario_base - NEW.descontos - NEW.horas_extras - NEW.comissao; 
    UPDATE tbl_salario SET valor_liquido = valor_liquido WHERE id_salario = NEW.id_salario;
END;

--  criação de uma stored function que retorna o salário líquido de um determinado funcionário para um mês e ano específicos:

-- Criação da stored function
CREATE FUNCTION calcular_salario_liquido(id_funcionario INT, mes INT, ano INT)
RETURNS DECIMAL(10, 2)
BEGIN
    DECLARE salario_base DECIMAL(10, 2);
    DECLARE horas_extras DECIMAL(10, 2);
    DECLARE comissao DECIMAL(10, 2);
    DECLARE descontos DECIMAL(10, 2);
    DECLARE valor_liquido DECIMAL(10, 2);
    
    SELECT salario_base, horas_extras, comissao, descontos, valor_liquido
    INTO salario_base, horas_extras, comissao, descontos, valor_liquido
    FROM tbl_Salario
    WHERE id_funcionario = id_funcionario
        AND MONTH(data_referencia) = mes
        AND YEAR(data_referencia) = ano;
    
    RETURN valor_liquido;
END;
SELECT calcular_salario_liquido(1, 1, 2022); -- chamar função .

-- 4. Crie ao menos um índice composto para uma das tabelas---------------------------------------------------------------------------

--  índice composto permitirá que consultas que envolvam a filtragem ou ordenação por nome e nascimento sejam executadas.
-- Os dados estarão pré-ordenados de acordo com essas duas colunas.

CREATE INDEX idx_nome_nascimento ON tbl_funcionario (nome, nascimento);




